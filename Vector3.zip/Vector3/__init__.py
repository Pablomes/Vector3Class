import math


class Vector3:

    def __init__(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

    def __repr__(self):
        return f"[{self.x}, {self.y}, {self.z}]"

    def __mul__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x * other, self.y * other, self.z * other)

    def __imul__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x * other, self.y * other, self.z * other)

    def __rmul__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x * other, self.y * other, self.z * other)

    def __add__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __iadd__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __radd__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)

    def __isub__(self, other):
        if isinstance(other, Vector3):
            return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)

    def __truediv__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x / other, self.y / other, self.z / other)

    def __itruediv__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x / other, self.y / other, self.z / other)

    def __eq__(self, other):
        if isinstance(other, Vector3):
            if self.x == other.x and self.y == other.y and self.z == other.z:
                return True

        return False

    def __ne__(self, other):
        if isinstance(other, Vector3):
            if self.x == other.x and self.y == other.y and self.z == other.z:
                return False

        return True

    def __neg__(self):
        return self * -1

    def __floordiv__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x // other, self.y // other, self.z // other)

    def __ifloordiv__(self, other):
        if isinstance(other, float) or isinstance(other, int):
            return Vector3(self.x // other, self.y // other, self.z // other)

    def __int__(self):
        return Vector3(int(self.x), int(self.y), int(self.z))

    def set_params(self, x: float, y: float, z: float):
        self.x = x
        self.y = y
        self.z = z

    @staticmethod
    def dot(vector1, vector2) -> float:
        return vector1.x * vector2.x + vector1.y * vector2.y + vector1.z * vector2.z

    @staticmethod
    def cross(vector1, vector2):
        new_x = vector1.y * vector2.z - vector1.z * vector2.y
        new_y = vector1.z * vector2.x - vector1.x * vector2.z
        new_z = vector1.x * vector2.y - vector1.y * vector2.x

        return Vector3(new_x, new_y, new_z)

    @staticmethod
    def mixed(vector1, vector2, vector3) -> float:
        return Vector3.dot(vector1, Vector3.cross(vector2, vector3))

    @staticmethod
    def triple_cross(vector1, vector2, vector3):
        return Vector3.cross(vector1, Vector3.cross(vector2, vector3))

    def mod(self=None) -> float:
        if self:
            return (self.sqr_mod()) ** (1 / 2)
        else:
            return 0

    @staticmethod
    def angle(vector1, vector2) -> float:
        return math.acos(Vector3.dot(vector1, vector2) / vector1.mod() * vector2.mod())

    @staticmethod
    def angle_deg(vector1, vector2) -> float:
        return Vector3.angle(vector1, vector2) * 180 / math.pi

    def normalise(self=None):
        if self:
            mod = self.mod()
            self.set_params(self.x / mod, self.y / mod, self.z / mod)
            return self
        else:
            return 0

    @staticmethod
    def one():
        return Vector3(1, 1, 1)

    @staticmethod
    def zero():
        return Vector3(0, 0, 0)

    def sqr_mod(self=None):
        if self:
            return self.x ** 2 + self.y ** 2 + self.z ** 2
        else:
            return 0

    def set_length(self, length=1):
        new_vector = self.normalise() * length
        self.set_params(new_vector.x, new_vector.y, new_vector.z)
        return self

    def clamp_mod(self, max_length=1):
        if self.mod() > max_length:
            self.set_length(max_length)
        return self

    @staticmethod
    def distance(a, b) -> float:
        new_vector = b - a
        return new_vector.mod()

    @staticmethod
    def project(vector, on_vector):
        return (Vector3.dot(vector, on_vector) / on_vector.mod() ** 2) * on_vector

    @staticmethod
    def comp_mult(vector1, vector2):
        return Vector3(vector1.x * vector2.x, vector1.y * vector2.y, vector1.z * vector2.z)
